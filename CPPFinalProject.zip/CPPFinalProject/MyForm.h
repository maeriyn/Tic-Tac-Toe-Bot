﻿#pragma once
#include <cmath>

namespace CPPFinalProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form{
	
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ btn8;
	protected:

	private: System::Windows::Forms::TextBox^ txtDisplay;
	private: System::Windows::Forms::Button^ btn4;
	protected:


	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ Delete;

	private: System::Windows::Forms::Button^ PlusMinus;

	private: System::Windows::Forms::Button^ Clear;

	private: System::Windows::Forms::Button^ btn5;

	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ btn9;

	private: System::Windows::Forms::Button^ btn7;

	private: System::Windows::Forms::Button^ btn3;

	private: System::Windows::Forms::Button^ btn2;
	private: System::Windows::Forms::Button^ btn6;


	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Button^ btn1;

	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::Button^ EqualBtn;

	private: System::Windows::Forms::Button^ btn0;
	private: System::Windows::Forms::Button^ DecimalBtn;
	private: System::Windows::Forms::Button^ Sqrt;
	private: System::Windows::Forms::Button^ Square;

	private: System::Windows::Forms::Button^ ln;

	private: System::Windows::Forms::Button^ log;
	private: System::Windows::Forms::Button^ ysquare;

	private: System::Windows::Forms::Button^ tenthp;








	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->txtDisplay = (gcnew System::Windows::Forms::TextBox());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->PlusMinus = (gcnew System::Windows::Forms::Button());
			this->Clear = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->EqualBtn = (gcnew System::Windows::Forms::Button());
			this->btn0 = (gcnew System::Windows::Forms::Button());
			this->DecimalBtn = (gcnew System::Windows::Forms::Button());
			this->Sqrt = (gcnew System::Windows::Forms::Button());
			this->Square = (gcnew System::Windows::Forms::Button());
			this->ln = (gcnew System::Windows::Forms::Button());
			this->log = (gcnew System::Windows::Forms::Button());
			this->ysquare = (gcnew System::Windows::Forms::Button());
			this->tenthp = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// btn8
			// 
			this->btn8->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn8->Location = System::Drawing::Point(125, 203);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(107, 110);
			this->btn8->TabIndex = 0;
			this->btn8->Text = L"8";
			this->btn8->UseVisualStyleBackColor = true;
			this->btn8->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// txtDisplay
			// 
			this->txtDisplay->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->txtDisplay->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->txtDisplay->Location = System::Drawing::Point(12, 12);
			this->txtDisplay->Multiline = true;
			this->txtDisplay->Name = L"txtDisplay";
			this->txtDisplay->Size = System::Drawing::Size(672, 53);
			this->txtDisplay->TabIndex = 1;
			this->txtDisplay->Text = L"0";
			this->txtDisplay->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// btn4
			// 
			this->btn4->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn4->Location = System::Drawing::Point(12, 319);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(107, 110);
			this->btn4->TabIndex = 2;
			this->btn4->Text = L"4";
			this->btn4->UseVisualStyleBackColor = true;
			this->btn4->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// button3
			// 
			this->button3->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(351, 87);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(107, 110);
			this->button3->TabIndex = 3;
			this->button3->Text = L"÷";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::EnterOperator);
			// 
			// Delete
			// 
			this->Delete->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24));
			this->Delete->Location = System::Drawing::Point(238, 87);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(107, 110);
			this->Delete->TabIndex = 4;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &MyForm::Delete_Click);
			// 
			// PlusMinus
			// 
			this->PlusMinus->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->PlusMinus->Location = System::Drawing::Point(125, 87);
			this->PlusMinus->Name = L"PlusMinus";
			this->PlusMinus->Size = System::Drawing::Size(107, 110);
			this->PlusMinus->TabIndex = 5;
			this->PlusMinus->Text = L"+/-";
			this->PlusMinus->UseVisualStyleBackColor = true;
			this->PlusMinus->Click += gcnew System::EventHandler(this, &MyForm::PlusMinus_Click);
			// 
			// Clear
			// 
			this->Clear->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->Clear->Location = System::Drawing::Point(12, 87);
			this->Clear->Name = L"Clear";
			this->Clear->Size = System::Drawing::Size(107, 110);
			this->Clear->TabIndex = 6;
			this->Clear->Text = L"C";
			this->Clear->UseVisualStyleBackColor = true;
			this->Clear->Click += gcnew System::EventHandler(this, &MyForm::Clear_Click);
			// 
			// btn5
			// 
			this->btn5->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn5->Location = System::Drawing::Point(125, 319);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(107, 110);
			this->btn5->TabIndex = 7;
			this->btn5->Text = L"5";
			this->btn5->UseVisualStyleBackColor = true;
			this->btn5->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// button8
			// 
			this->button8->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->Location = System::Drawing::Point(351, 203);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(107, 110);
			this->button8->TabIndex = 8;
			this->button8->Text = L"x";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::EnterOperator);
			// 
			// btn9
			// 
			this->btn9->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn9->Location = System::Drawing::Point(238, 203);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(107, 110);
			this->btn9->TabIndex = 9;
			this->btn9->Text = L"9";
			this->btn9->UseVisualStyleBackColor = true;
			this->btn9->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// btn7
			// 
			this->btn7->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn7->Location = System::Drawing::Point(12, 203);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(107, 110);
			this->btn7->TabIndex = 10;
			this->btn7->Text = L"7";
			this->btn7->UseVisualStyleBackColor = true;
			this->btn7->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// btn3
			// 
			this->btn3->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn3->Location = System::Drawing::Point(238, 435);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(107, 110);
			this->btn3->TabIndex = 11;
			this->btn3->Text = L"3";
			this->btn3->UseVisualStyleBackColor = true;
			this->btn3->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// btn2
			// 
			this->btn2->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn2->Location = System::Drawing::Point(125, 435);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(107, 110);
			this->btn2->TabIndex = 12;
			this->btn2->Text = L"2";
			this->btn2->UseVisualStyleBackColor = true;
			this->btn2->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// btn6
			// 
			this->btn6->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn6->Location = System::Drawing::Point(238, 319);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(107, 110);
			this->btn6->TabIndex = 13;
			this->btn6->Text = L"6";
			this->btn6->UseVisualStyleBackColor = true;
			this->btn6->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// button14
			// 
			this->button14->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button14->Location = System::Drawing::Point(351, 319);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(107, 110);
			this->button14->TabIndex = 14;
			this->button14->Text = L"-";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::EnterOperator);
			// 
			// btn1
			// 
			this->btn1->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn1->Location = System::Drawing::Point(12, 435);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(107, 110);
			this->btn1->TabIndex = 15;
			this->btn1->Text = L"1";
			this->btn1->UseVisualStyleBackColor = true;
			this->btn1->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// button16
			// 
			this->button16->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button16->Location = System::Drawing::Point(351, 435);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(107, 110);
			this->button16->TabIndex = 16;
			this->button16->Text = L"+";
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &MyForm::EnterOperator);
			// 
			// EqualBtn
			// 
			this->EqualBtn->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->EqualBtn->Location = System::Drawing::Point(351, 551);
			this->EqualBtn->Name = L"EqualBtn";
			this->EqualBtn->Size = System::Drawing::Size(107, 110);
			this->EqualBtn->TabIndex = 20;
			this->EqualBtn->Text = L"=";
			this->EqualBtn->UseVisualStyleBackColor = true;
			this->EqualBtn->Click += gcnew System::EventHandler(this, &MyForm::EqualBtn_Click);
			// 
			// btn0
			// 
			this->btn0->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->btn0->Location = System::Drawing::Point(12, 551);
			this->btn0->Name = L"btn0";
			this->btn0->Size = System::Drawing::Size(220, 110);
			this->btn0->TabIndex = 19;
			this->btn0->Text = L"0";
			this->btn0->UseVisualStyleBackColor = true;
			this->btn0->Click += gcnew System::EventHandler(this, &MyForm::EnterNumber);
			// 
			// DecimalBtn
			// 
			this->DecimalBtn->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 25));
			this->DecimalBtn->Location = System::Drawing::Point(238, 551);
			this->DecimalBtn->Name = L"DecimalBtn";
			this->DecimalBtn->Size = System::Drawing::Size(107, 110);
			this->DecimalBtn->TabIndex = 17;
			this->DecimalBtn->Text = L".";
			this->DecimalBtn->UseVisualStyleBackColor = true;
			this->DecimalBtn->Click += gcnew System::EventHandler(this, &MyForm::DecimalBtn_Click);
			// 
			// Sqrt
			// 
			this->Sqrt->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Sqrt->Location = System::Drawing::Point(464, 87);
			this->Sqrt->Name = L"Sqrt";
			this->Sqrt->Size = System::Drawing::Size(107, 110);
			this->Sqrt->TabIndex = 21;
			this->Sqrt->Text = L"√";
			this->Sqrt->UseVisualStyleBackColor = true;
			this->Sqrt->Click += gcnew System::EventHandler(this, &MyForm::Sqrt_Click);
			// 
			// Square
			// 
			this->Square->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Square->Location = System::Drawing::Point(464, 435);
			this->Square->Name = L"Square";
			this->Square->Size = System::Drawing::Size(107, 110);
			this->Square->TabIndex = 22;
			this->Square->Text = L"𝑥^2";
			this->Square->UseVisualStyleBackColor = true;
			this->Square->Click += gcnew System::EventHandler(this, &MyForm::Square_Click);
			// 
			// ln
			// 
			this->ln->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ln->Location = System::Drawing::Point(464, 319);
			this->ln->Name = L"ln";
			this->ln->Size = System::Drawing::Size(107, 110);
			this->ln->TabIndex = 23;
			this->ln->Text = L"ln";
			this->ln->UseVisualStyleBackColor = true;
			this->ln->Click += gcnew System::EventHandler(this, &MyForm::ln_Click);
			// 
			// log
			// 
			this->log->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->log->Location = System::Drawing::Point(464, 203);
			this->log->Name = L"log";
			this->log->Size = System::Drawing::Size(107, 110);
			this->log->TabIndex = 24;
			this->log->Text = L"log";
			this->log->UseVisualStyleBackColor = true;
			this->log->Click += gcnew System::EventHandler(this, &MyForm::log_Click);
			// 
			// ysquare
			// 
			this->ysquare->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ysquare->Location = System::Drawing::Point(464, 551);
			this->ysquare->Name = L"ysquare";
			this->ysquare->Size = System::Drawing::Size(107, 110);
			this->ysquare->TabIndex = 25;
			this->ysquare->Text = L"x^y";
			this->ysquare->UseVisualStyleBackColor = true;
			this->ysquare->Click += gcnew System::EventHandler(this, &MyForm::EnterOperator);
			// 
			// tenthp
			// 
			this->tenthp->Font = (gcnew System::Drawing::Font(L"Mongolian Baiti", 24.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tenthp->Location = System::Drawing::Point(577, 87);
			this->tenthp->Name = L"tenthp";
			this->tenthp->Size = System::Drawing::Size(107, 110);
			this->tenthp->TabIndex = 27;
			this->tenthp->Text = L"10^x";
			this->tenthp->UseVisualStyleBackColor = true;
			this->tenthp->Click += gcnew System::EventHandler(this, &MyForm::tenthp_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1199, 673);
			this->Controls->Add(this->tenthp);
			this->Controls->Add(this->ysquare);
			this->Controls->Add(this->log);
			this->Controls->Add(this->ln);
			this->Controls->Add(this->Square);
			this->Controls->Add(this->Sqrt);
			this->Controls->Add(this->EqualBtn);
			this->Controls->Add(this->btn0);
			this->Controls->Add(this->DecimalBtn);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->btn1);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->btn6);
			this->Controls->Add(this->btn2);
			this->Controls->Add(this->btn3);
			this->Controls->Add(this->btn7);
			this->Controls->Add(this->btn9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->btn5);
			this->Controls->Add(this->Clear);
			this->Controls->Add(this->PlusMinus);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->btn4);
			this->Controls->Add(this->txtDisplay);
			this->Controls->Add(this->btn8);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		double firstDigit, secondDigit, result;
		String^ operators;

	private: System::Void EnterNumber(System::Object^ sender, System::EventArgs^ e) {
		Button^ Numbers = safe_cast<Button^>(sender);

		if (txtDisplay->Text == "0") {
			txtDisplay->Text = Numbers->Text;
		}
		else {
			txtDisplay->Text = txtDisplay->Text + Numbers->Text;
		}
	}

	private: System::Void EnterOperator(System::Object^ sender, System::EventArgs^ e) {
		Button^ NumbersOp = safe_cast<Button^>(sender);
		firstDigit = Double::Parse(txtDisplay->Text);
		txtDisplay->Text = "";
		operators = NumbersOp->Text;
	}
	private: System::Void DecimalBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		if (!txtDisplay->Text->Contains(".")) {
			txtDisplay->Text = txtDisplay->Text + ".";
		}
	}
	private: System::Void EqualBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		secondDigit = Double::Parse(txtDisplay->Text);
		if (operators == "+") {
			result = firstDigit + secondDigit;
			txtDisplay->Text = System::Convert::ToString(result);
		}
		else if (operators == "-") {
			result = firstDigit - secondDigit;
			txtDisplay->Text = System::Convert::ToString(result);
		}
		else if (operators == "*") {
			result = firstDigit * secondDigit;
			txtDisplay->Text = System::Convert::ToString(result);
		}
		else if (operators == "/") {
			result = firstDigit / secondDigit;
			txtDisplay->Text = System::Convert::ToString(result);
		}
		else if (operators == "x^y") {
			result = pow (firstDigit, secondDigit);
			txtDisplay->Text = System::Convert::ToString(result);
		}
		/*else if (operators == "y√x") {
			result = pow(firstDigit, 1/secondDigit);
			txtDisplay->Text = System::Convert::ToString(result);
		}*/

	}
	private: System::Void Clear_Click(System::Object^ sender, System::EventArgs^ e) {
		txtDisplay->Text = "0";
	}
	private: System::Void PlusMinus_Click(System::Object^ sender, System::EventArgs^ e) {
		if (txtDisplay->Text->Contains("-")) {
			txtDisplay->Text = txtDisplay->Text->Remove(0, 1);
		}
		else {
			txtDisplay->Text = "-" + txtDisplay->Text;
		}
	}
	private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
		if (txtDisplay->Text->Length > 0) {
			txtDisplay->Text = txtDisplay->Text->Remove(txtDisplay->Text->Length - 1, 1);
		}
	}

	private: System::Void Sqrt_Click(System::Object^ sender, System::EventArgs^ e) {
		firstDigit = Double::Parse(txtDisplay->Text);
		result = sqrt(firstDigit);
		txtDisplay->Text = System::Convert::ToString(result);
	}
	private: System::Void log_Click(System::Object^ sender, System::EventArgs^ e) {
		firstDigit = Double::Parse(txtDisplay->Text);
		result = log10(firstDigit);
		txtDisplay->Text = System::Convert::ToString(result);
	}
	private: System::Void ln_Click(System::Object^ sender, System::EventArgs^ e) {
		firstDigit = Double::Parse(txtDisplay->Text);
		result = logl(firstDigit);
		txtDisplay->Text = System::Convert::ToString(result);
	}

	private: System::Void Square_Click(System::Object^ sender, System::EventArgs^ e) {
		firstDigit = Double::Parse(txtDisplay->Text);
		result = (firstDigit*firstDigit);
		txtDisplay->Text = System::Convert::ToString(result);
	}

/*private: System::Void factorial_Click(System::Object^ sender, System::EventArgs^ e) {
	firstDigit = Double::Parse(txtDisplay->Text);
	int t = firstDigit;
	for (int i = 0; i < t; ++i) {
		result *= firstDigit -1;
		--firstDigit;
		}
	txtDisplay->Text = System::Convert::ToString(result);
}*/
private: System::Void tenthp_Click(System::Object^ sender, System::EventArgs^ e) {
	firstDigit = Double::Parse(txtDisplay->Text);
	result = pow(10, firstDigit);
	txtDisplay->Text = System::Convert::ToString(result);
}
};
}
